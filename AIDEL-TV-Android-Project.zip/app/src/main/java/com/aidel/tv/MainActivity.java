package com.aidel.tv;

import android.os.Bundle;
import android.widget.TextView;
import androidx.fragment.app.FragmentActivity;

public class MainActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView title = findViewById(R.id.title);
        if (title != null) {
            title.setText("Aidel TV");
        }
    }
}
